<?php
/**
 * User: shahnuralam
 * Date: 5/7/17
 * Time: 10:59 AM
 */
if(!defined('ABSPATH')) die('!');
?>
<iframe src="//cdn.wpdownloadmanager.com/notice.php?wpdmvarsion=<?php echo WPDM_VERSION; ?>" style="height: 400px;width:100%;border:0px"></iframe>
